function Mu=LPV_kff_1(Xg,Xr,Ur,p,Fv,Km)
Mu=Ur;
end
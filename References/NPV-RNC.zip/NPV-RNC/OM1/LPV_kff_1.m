function Mu=LPV_kff_1(Xg,Xr,Ur,Qdd,p,Fv,Km)
Mu=Ur;
end